package com.eventos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.eventos.entity.Event;
import com.eventos.services.services_abstract.IEventService;

import lombok.AllArgsConstructor;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@AllArgsConstructor
@RequestMapping("/api/v1/events")
public class EventController {
  @Autowired
  private final IEventService objIEventService;

  @GetMapping
  public ResponseEntity<Page<Event>> getAll(Pageable objPageable) {
    return ResponseEntity.ok(this.objIEventService.getAll(objPageable));
  }
  @PostMapping
  public ResponseEntity<Event> insert (@RequestBody Event objEvent){
    return ResponseEntity.ok(this.objIEventService.save(objEvent));
  }
  @GetMapping(path = "/{id}")
  public ResponseEntity<Event> findById (@PathVariable Long id){
    return ResponseEntity.ok(this.objIEventService.findById(id));
  }
  @PutMapping(path = "/update/{id}")
  public ResponseEntity<Event> update (@PathVariable Long id , @RequestBody Event objEvent){
    return ResponseEntity.ok(this.objIEventService.update(id,objEvent));
  }
  @DeleteMapping(path = "/delete/{id}")
  public ResponseEntity<Void> delete(@PathVariable Long id){
   this.objIEventService.delete(id);
   return ResponseEntity.noContent().build();
  }
}
